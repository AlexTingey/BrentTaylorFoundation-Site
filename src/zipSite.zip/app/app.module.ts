import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OriginalSiteComponent } from './original-site/original-site.component';
import { HeaderComponent } from './header/header.component';
import { ScrollerComponent } from './scroller/scroller.component';
import { NewsComponent } from './news/news.component';
import { DonateComponent } from './donate/donate.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { SplashComponent } from './splash/splash.component';
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';

@NgModule({
  declarations: [
    AppComponent,
    OriginalSiteComponent,
    HeaderComponent,
    ScrollerComponent,
    NewsComponent,
    DonateComponent,
    AboutComponent,
    ContactComponent,
    SplashComponent,
    HomeComponent,
    NavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
